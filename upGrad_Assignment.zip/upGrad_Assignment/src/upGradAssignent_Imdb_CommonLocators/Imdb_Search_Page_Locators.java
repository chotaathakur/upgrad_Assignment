package upGradAssignent_Imdb_CommonLocators;

import org.openqa.selenium.By;

public class Imdb_Search_Page_Locators {
	public static final Object movieDetailsTable = By
			.cssSelector("#main > div > span > div > div > div.lister > table > tbody"),
			noOfMovies=By.tagName("tr"),
			movieTable = By.className("titleColumn"), 
			movieTitleFetch = By.xpath("./a"),
			movieReleaseFetch = By.xpath("./span"),
			movieRating = By.cssSelector("td.ratingColumn.imdbRating"),
			movieRatingFetch = By.xpath("./strong");
			

}
