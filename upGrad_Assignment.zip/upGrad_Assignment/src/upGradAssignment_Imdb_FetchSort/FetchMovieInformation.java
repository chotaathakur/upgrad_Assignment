package upGradAssignment_Imdb_FetchSort;

import java.util.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import upGradAssignent_Imdb_CommonLocators.Imdb_Landing_Page_Locators;
import upGradAssignent_Imdb_CommonLocators.Imdb_Search_Page_Locators;

import java.io.*;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;

public class FetchMovieInformation extends CreateExcel {

	public static WebDriver driver;
	public static WebElement movieTable;
	public static int noOfItems;
	public static String filename = "D:/UpGradAssignment_StoredInformation.xls";
	public static String chromedriverpath = "D:/Automation/Setups/Drivers/chromedriver.exe";

	public static WebDriver LaunchChrome() {
		System.setProperty("webdriver.chrome.driver", chromedriverpath);
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		return driver;
	}

	public static void createExcel() {

		workbook = new HSSFWorkbook();
		sheet = workbook.createSheet("MovieInformation");

		rowhead = sheet.createRow((short) 0);

		cell = rowhead.createCell(0);
		rowhead.getCell(0).setCellValue("Movie Title");
		setBorder(cell);
		setColor(cell);
		cell = rowhead.createCell(1);
		rowhead.getCell(1).setCellValue("Movie Release");
		setBorder(cell);
		setColor(cell);
		cell = rowhead.createCell(2);
		rowhead.getCell(2).setCellValue("Movie Rating");
		setBorder(cell);
		setColor(cell);
	}

	public static void writeExcel() throws IOException {
		FileOutputStream fileOut = new FileOutputStream(filename);
		workbook.write(fileOut);
		fileOut.close();
		workbook.close();
		System.out.println("Please go to the path " + filename + " to see the fetched results");
	}

	public static void launchIMDBTop250Page() {
		driver.get("https://www.imdb.com/");
		WebElement dropdown = driver.findElement((By) Imdb_Landing_Page_Locators.movieDropdown);
		Actions actions = new Actions(driver);

		actions.moveToElement(dropdown).perform();

		WebDriverWait wait = new WebDriverWait(driver, 100);

		wait.until(ExpectedConditions.elementToBeClickable((By) Imdb_Landing_Page_Locators.topRatedMovies));

		driver.findElement((By) Imdb_Landing_Page_Locators.topRatedMovies).click();
		movieTable = driver.findElement((By) Imdb_Search_Page_Locators.movieDetailsTable);
		noOfItems = movieTable.findElements((By) Imdb_Search_Page_Locators.noOfMovies).size();
	

	}

	public static void storeMovieTitles() throws IOException {

		List<WebElement> title = driver.findElements((By) Imdb_Search_Page_Locators.movieTable);
		Iterator<WebElement> itr = title.iterator();

		noOfItems = 1;
		while (itr.hasNext() && noOfItems <= 250) {
			WebElement sortIterator = itr.next();
			if (sortIterator.isDisplayed()) {
				String MovieTitleElement = sortIterator.findElement((By) Imdb_Search_Page_Locators.movieTitleFetch)
						.getText();

				rowhead = sheet.createRow((short) noOfItems);
				cell = rowhead.createCell(0);
				rowhead.getCell(0).setCellValue(MovieTitleElement);

				noOfItems++;

			}
		}
		sheet.autoSizeColumn(0);
	}

	public static void storeMovieRelease() throws IOException {
		List<WebElement> releasedate = driver.findElements((By) Imdb_Search_Page_Locators.movieTable);
		Iterator<WebElement> itr = releasedate.iterator();

		noOfItems = 1;
		while (itr.hasNext() && noOfItems <= 250) {
			WebElement sortIterator = itr.next();
			if (sortIterator.isDisplayed()) {

				String MovieReleaseElement = sortIterator.findElement((By) Imdb_Search_Page_Locators.movieReleaseFetch)
						.getText();

				MovieReleaseElement = MovieReleaseElement.replaceAll("\\p{P}", "");

				float MovieReleaseDate = Integer.parseInt(MovieReleaseElement);
				rowhead = sheet.getRow((short) noOfItems);
				cell = rowhead.createCell(1);
				rowhead.getCell(1).setCellValue(MovieReleaseDate);

				noOfItems++;

			}

		}
		sheet.autoSizeColumn(1);
	}

	public static void storeMovieRatings() throws IOException {

		List<WebElement> movieratings = driver.findElements((By) Imdb_Search_Page_Locators.movieRating);
		Iterator<WebElement> itr = movieratings.iterator();

		noOfItems = 1;
		while (itr.hasNext() && noOfItems <= 250) {
			WebElement sortIterator = itr.next();
			if (sortIterator.isDisplayed()) {

				String IMDbMovieRatings = sortIterator.findElement((By) Imdb_Search_Page_Locators.movieRatingFetch)
						.getText();

				rowhead = sheet.getRow((short) noOfItems);
				cell = rowhead.createCell(2);
				rowhead.getCell(2).setCellValue(IMDbMovieRatings);

				noOfItems++;

			}
		}
		sheet.autoSizeColumn(2);
	}

	public static void main(String args[]) {
		driver = LaunchChrome();
		createExcel();
		launchIMDBTop250Page();

		try {
			System.out.println("Storing Movie Titles... ");
			storeMovieTitles();
			System.out.println("Movie Titles Stored! ");
			System.out.println("Storing Movie Release Date... ");
			storeMovieRelease();
			System.out.println("Movie Release Date Stored! ");
			System.out.println("Storing Movie Ratings... ");
			storeMovieRatings();
			System.out.println("Movie Ratings Stored!");

			writeExcel();

		} catch (Exception e) {
			System.out.println("Script Failed");
			driver.quit();

		}
		driver.quit();

	}

}
