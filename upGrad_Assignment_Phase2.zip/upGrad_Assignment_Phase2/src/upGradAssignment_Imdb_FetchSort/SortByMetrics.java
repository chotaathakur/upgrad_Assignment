package upGradAssignment_Imdb_FetchSort;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.ListIterator;
import java.util.NoSuchElementException;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.openqa.selenium.By;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import upGradAssignent_Imdb_CommonLocators.Imdb_SortingPage_Locators;

public class SortByMetrics extends FetchMovieInformation {

	public static WebElement DropdownElement;
	public static Select dropdown;
	public static int rankAtCurrentIndexAsc[] = new int[250];
	public static int rankAtNextIndexAsc[] = new int[250];
	public static String sortedMetricStringAscending, sortedMetricStringDescending;

	public static void dropdown() {

		DropdownElement = driver.findElement((By) Imdb_SortingPage_Locators.sortDropdown);
		dropdown = new Select(DropdownElement);

	}

	public static void storeReports(String sortMetricsName) throws IOException {
		String fileName = sortMetricsName;
		String pathName = "D:/" + fileName + ".xls";

		FileOutputStream fileOut = new FileOutputStream(pathName);
		workbook.write(fileOut);
		fileOut.close();
		workbook.close();
		System.out.println("Please go to the path " + pathName + " to see the fetched results");
		System.out.println();
	}

	public static void sortButton() {
		driver.findElement((By) Imdb_SortingPage_Locators.sortButton).click();
	}

	public static void createExcelSheet() {
		workbook = new HSSFWorkbook();
		sheet = workbook.createSheet("Ascending Rankings");
		rowhead = sheet.createRow((short) 0);

		cell = rowhead.createCell(0);
		rowhead.getCell(0).setCellValue("Ascending Result");
		setBorder(cell);
		setColor(cell);
		cell = rowhead.createCell(1);
		rowhead.getCell(1).setCellValue("Ascending Status");
		setBorder(cell);
		setColor(cell);

		sheet2 = workbook.createSheet("Descending Rankings");
		rowhead2 = sheet2.createRow((short) 0);
		cell2 = rowhead2.createCell(0);
		rowhead2.getCell(0).setCellValue("Descending Result");
		setBorder(cell2);
		setColor(cell2);

		cell2 = rowhead2.createCell(1);
		rowhead2.getCell(1).setCellValue("Descending Status");
		setBorder(cell2);
		setColor(cell2);

	}

	public static void writeOutputToSheet1(float currentRatingStoreAsc, float nextRatingStoreAsc) {
		rowhead = sheet.createRow((short) noOfItems);
		cell = rowhead.createCell(0);
		rowhead.getCell(0)
				.setCellValue(currentRatingStoreAsc + " " + sortedMetricStringAscending + " " + nextRatingStoreAsc);
		rowhead.createCell(1).setCellValue("Pass");
		sheet.autoSizeColumn(0);
		sheet.autoSizeColumn(1);
	}

	public static void writeOutputToSheet2(float currentRatingStoreDesc, float nextRatingStoreDesc) {
		rowhead2 = sheet2.createRow((short) noOfItems);
		cell2 = rowhead2.createCell(0);
		rowhead2.getCell(0)
				.setCellValue(currentRatingStoreDesc + " " + sortedMetricStringDescending + " " + nextRatingStoreDesc);
		rowhead2.createCell(1).setCellValue("Pass");
		sheet2.autoSizeColumn(0);
		sheet2.autoSizeColumn(1);
	}

	public static void sortByRankings(String sortOrder) {

		if (sortOrder == "descending") {
			sortedMetricStringDescending = "is ranked lower than";
			System.out.println("Sort By Rankings Descending will be verified");
			sortButton();
		} else {
			sortedMetricStringAscending = "is ranked higher than";
			System.out.println("Sort By Rankings Ascending will be verified");
		}

		dropdown.selectByVisibleText("Ranking");
		List<WebElement> movieRankTable = driver.findElements((By) Imdb_SortingPage_Locators.movieTable);
		ListIterator<WebElement> itr = movieRankTable.listIterator();

		noOfItems = 1;

		while (itr.hasNext() && noOfItems <= 249) {
			WebElement sortIterator = itr.next();
			if (sortIterator.isDisplayed()) {

				String ranking = driver.findElement(By.cssSelector("tr:nth-child(" + noOfItems + ") > td.titleColumn"))
						.getText();
				ranking = ranking.replaceAll("[^0-9]", "");
				if (noOfItems <= 9 && sortOrder == "ascending") {
					ranking = ranking.substring(0, 1);
				} else if (noOfItems <= 99 && sortOrder == "ascending") {
					ranking = ranking.substring(0, 2);
				} else if (noOfItems <= 250 && noOfItems > 241 && sortOrder == "descending") {
					ranking = ranking.substring(0, 1);
				} else if (noOfItems <= 241 && noOfItems > 151 && sortOrder == "descending") {
					ranking = ranking.substring(0, 2);
				} else if (noOfItems <= 151 && sortOrder == "descending") {
					ranking = ranking.substring(0, 3);
				} else {
					ranking = ranking.substring(0, 3);
				}
				int currentRankingStore = Integer.parseInt(ranking);
				rankAtCurrentIndexAsc[noOfItems] = currentRankingStore;
				try {
					itr.next();
					String nextElementStorage = driver
							.findElement(By.cssSelector("tr:nth-child(" + (noOfItems + 1) + ") > td.titleColumn"))
							.getText();
					nextElementStorage = nextElementStorage.replaceAll("[^0-9]", "");
					if ((noOfItems + 1) <= 9 && sortOrder == "ascending") {
						nextElementStorage = nextElementStorage.substring(0, 1);
					} else if ((noOfItems + 1) <= 99 && (noOfItems + 1 > 9) && sortOrder == "ascending") {
						nextElementStorage = nextElementStorage.substring(0, 2);
					} else if ((noOfItems + 1) <= 250 && (noOfItems + 1) > 241 && sortOrder == "descending") {
						nextElementStorage = nextElementStorage.substring(0, 1);
					} else if ((noOfItems + 1) <= 241 && (noOfItems + 1) > 151 && sortOrder == "descending") {
						nextElementStorage = nextElementStorage.substring(0, 2);
					} else if ((noOfItems + 1) <= 151 && sortOrder == "descending") {
						nextElementStorage = nextElementStorage.substring(0, 3);
					} else {
						nextElementStorage = nextElementStorage.substring(0, 3);
					}
					int nextRankingStore = Integer.parseInt(nextElementStorage);
					rankAtNextIndexAsc[noOfItems] = nextRankingStore;

					if (currentRankingStore < nextRankingStore && sortOrder == "ascending") {
						writeOutputToSheet1((int) currentRankingStore, (int) nextRankingStore);

					} else if (currentRankingStore > nextRankingStore && sortOrder == "descending") {
						writeOutputToSheet2((int) currentRankingStore, (int) nextRankingStore);
					} else {
						if (sortOrder == "ascending") {
							rowhead.createCell(1).setCellValue("Fail");
						} else {
							rowhead2.createCell(1).setCellValue("Fail");
						}
					}
				} catch (NoSuchElementException e) {
					itr.previous();
				}
				noOfItems++;
				itr.previous();

			}

		}

	}

	public static void sortByIMDbRatings(String sortOrder) {

		dropdown.selectByVisibleText("IMDb Rating");
		if (sortOrder == "descending") {
			sortedMetricStringDescending = "has lower IMDb Rating than";
			System.out.println("Sort Descending for IMDbRating will be verified");
			sortButton();
		} else {
			sortedMetricStringAscending = "has higher IMDb Rating than";
			System.out.println("Sort Ascending for IMDbRating will be verified");
		}
		List<WebElement> movieratings = driver.findElements((By) Imdb_SortingPage_Locators.movieRating);
		ListIterator<WebElement> itr = movieratings.listIterator();

		noOfItems = 1;

		while (itr.hasNext() && noOfItems <= 250) {
			WebElement sortIterator = itr.next();
			if (sortIterator.isDisplayed()) {

				String IMDbMovieRatings = sortIterator.findElement((By) Imdb_SortingPage_Locators.movieRatingFetch)
						.getText();
				// System.out.println("Current Element: " +
				// IMDbMovieRatings);

				float CurrentRatingStore = Float.parseFloat(IMDbMovieRatings);
				try {
					WebElement SortCompare = itr.next();
					String nextElementStorage = SortCompare.findElement((By) Imdb_SortingPage_Locators.movieRatingFetch)
							.getText();
					float nextRatingStore = Float.parseFloat(nextElementStorage);

					if (CurrentRatingStore > nextRatingStore && sortOrder == "ascending") {
						writeOutputToSheet1(CurrentRatingStore, nextRatingStore);

					} else if (CurrentRatingStore < nextRatingStore && sortOrder == "descending") {
						writeOutputToSheet2(CurrentRatingStore, nextRatingStore);
					} else if (CurrentRatingStore == nextRatingStore && sortOrder == "ascending") {
						//sortedMetricStringAscending = "has same IMDb Rating but higher rank than";
						if (rankAtCurrentIndexAsc[noOfItems] > rankAtNextIndexAsc[noOfItems]) {
							writeOutputToSheet1(CurrentRatingStore, nextRatingStore);
						} else {

							rowhead.createCell(1).setCellValue("Fail");
						}

					} else if (CurrentRatingStore == nextRatingStore && sortOrder == "descending") {
						if (rankAtCurrentIndexAsc[noOfItems] < rankAtNextIndexAsc[noOfItems]) {
							rowhead2.createCell(1).setCellValue("Fail");
						} else {
							//sortedMetricStringDescending = "has same IMDb Rating but lower rank than";
							writeOutputToSheet2(CurrentRatingStore, nextRatingStore);
						}

					} else if (sortOrder == "ascending" && CurrentRatingStore > nextRatingStore) {
						rowhead.createCell(1).setCellValue("Fail");
					} else {
						rowhead2.createCell(1).setCellValue("Fail");
					}

				} catch (NoSuchElementException e) {
					itr.previous();
				}
				noOfItems++;
				itr.previous();

			}
		}
	}

	public static void sortByNoOfRatings(String sortOrder) {
		if (sortOrder == "descending") {
			sortedMetricStringDescending = "has lesser No. Of Ratings than";
			System.out.println("Sort Descending for No Of Ratings will be verified");
			sortButton();
		} else {
			sortedMetricStringAscending = "has higher No. Of Ratings than";
			System.out.println("Sort Ascending for No Of Ratings will be verified");
		}

		dropdown.selectByVisibleText("Number of Ratings");

		List<WebElement> noOfRatings = driver.findElements((By) Imdb_SortingPage_Locators.movieRating);
		ListIterator<WebElement> itr = noOfRatings.listIterator();

		noOfItems = 1;

		while (itr.hasNext() && noOfItems <= 250) {
			WebElement sortIterator = itr.next();
			if (sortIterator.isDisplayed()) {

				String TotalRatings = sortIterator.findElement((By) Imdb_SortingPage_Locators.movieRatingFetch)
						.getAttribute("title");

				TotalRatings = TotalRatings.replaceAll("[^0-9]", "");
				TotalRatings = TotalRatings.substring(2);
				int currentNoOfRatingStore = Integer.parseInt(TotalRatings);
				try {
					WebElement SortCompare = itr.next();
					String nextElementStorage = SortCompare.findElement((By) Imdb_SortingPage_Locators.movieRatingFetch)
							.getAttribute("title");
					nextElementStorage = nextElementStorage.replaceAll("[^0-9]", "");
					nextElementStorage = nextElementStorage.substring(2);
					int nextNoOfRatingStore = Integer.parseInt(nextElementStorage);

					if (currentNoOfRatingStore > nextNoOfRatingStore && sortOrder == "ascending") {
						writeOutputToSheet1((int) currentNoOfRatingStore, (int) nextNoOfRatingStore);
					} else if (currentNoOfRatingStore < nextNoOfRatingStore && sortOrder == "descending") {
						writeOutputToSheet2((int) currentNoOfRatingStore, (int) nextNoOfRatingStore);
					} else if (currentNoOfRatingStore == nextNoOfRatingStore && sortOrder == "ascending") {
						if (rankAtCurrentIndexAsc[noOfItems] > rankAtNextIndexAsc[noOfItems]) {
							writeOutputToSheet1(currentNoOfRatingStore, nextNoOfRatingStore);
						} else {
							rowhead2.createCell(1).setCellValue("Fail");
						}

					} else if (currentNoOfRatingStore == nextNoOfRatingStore && sortOrder == "descending") {
						if (rankAtCurrentIndexAsc[noOfItems] < rankAtNextIndexAsc[noOfItems]) {
							rowhead.createCell(1).setCellValue("Fail");
						} else {
							writeOutputToSheet2(currentNoOfRatingStore, nextNoOfRatingStore);
						}

					} else {
						if (sortOrder == "ascending") {
							rowhead.createCell(1).setCellValue("Fail");
						} else {
							rowhead2.createCell(1).setCellValue("Fail");
						}
					}
				} catch (NoSuchElementException e) {
					itr.previous();
				}
				noOfItems++;
				itr.previous();

			}
		}

	}

	public static void sortByReleaseDate(String sortOrder) {
		if (sortOrder == "descending") {
			sortedMetricStringDescending = "was released before";
			System.out.println("Sort Descending for Release Date will be verified");
			sortButton();
		} else {
			sortedMetricStringAscending = "was released after";
			System.out.println("Sort Ascending for Release Date will be verified");
		}

		dropdown.selectByVisibleText("Release Date");
		List<WebElement> movieReleaseTable = driver.findElements((By) Imdb_SortingPage_Locators.movieTable);
		ListIterator<WebElement> itr = movieReleaseTable.listIterator();

		noOfItems = 1;

		while (itr.hasNext() && noOfItems <= 250) {
			WebElement sortIterator = itr.next();

			if (sortIterator.isDisplayed()) {

				String releaseDate = sortIterator.findElement((By) Imdb_SortingPage_Locators.movieReleaseFetch)
						.getText();
				releaseDate = releaseDate.replaceAll("[^0-9]", "");

				int currentReleaseStore = Integer.parseInt(releaseDate);
				try {
					WebElement SortCompare = itr.next();
					String nextElementStorage = SortCompare
							.findElement((By) Imdb_SortingPage_Locators.movieReleaseFetch).getText();
					nextElementStorage = nextElementStorage.replaceAll("[^0-9]", "");

					int nextReleaseStore = Integer.parseInt(nextElementStorage);

					if (currentReleaseStore > nextReleaseStore && sortOrder == "ascending") {
						writeOutputToSheet1((int) currentReleaseStore, (int) nextReleaseStore);
					} else if (currentReleaseStore < nextReleaseStore && sortOrder == "descending") {
						writeOutputToSheet2((int) currentReleaseStore, (int) nextReleaseStore);

					} else if (currentReleaseStore == nextReleaseStore && sortOrder == "ascending") {
						sortedMetricStringAscending = "has same Release Date but is higher ranked";
						if (rankAtCurrentIndexAsc[noOfItems] > rankAtNextIndexAsc[noOfItems]) {
							writeOutputToSheet1(currentReleaseStore, nextReleaseStore);
						} else {

							rowhead.createCell(1).setCellValue("Fail");
						}

					} else if (currentReleaseStore == nextReleaseStore && sortOrder == "descending") {
						if (rankAtCurrentIndexAsc[noOfItems] < rankAtNextIndexAsc[noOfItems]) {

							rowhead2.createCell(1).setCellValue("Fail");
						} else {
							//sortedMetricStringAscending = "has same Release Date but is lower ranked";
							writeOutputToSheet2(currentReleaseStore, nextReleaseStore);
						}

					} else if (sortOrder == "ascending" && currentReleaseStore > nextReleaseStore) {
						rowhead.createCell(1).setCellValue("Fail");
					} else {
						rowhead2.createCell(1).setCellValue("Fail");
					}
				} catch (NoSuchElementException e) {
					itr.previous();
				}
				noOfItems++;
				itr.previous();

			}
		}

	}

	public static void main(String args[]) {
		driver = LaunchChrome();
		try {
			launchIMDBTop250Page();
			dropdown();

			createExcelSheet();
			sortByRankings("ascending");
			sortByRankings("descending");
			storeReports("upGradAssignment_sortByRankings");

			createExcelSheet();
			sortByReleaseDate("ascending");
			sortByReleaseDate("descending");
			storeReports("upGradAssignment_sortByReleaseDate");

			createExcelSheet();
			sortByIMDbRatings("ascending");
			sortByIMDbRatings("descending");
			storeReports("upGradAssignment_sortByIMDbRatings");

			createExcelSheet();
			sortByNoOfRatings("ascending");
			sortByNoOfRatings("descending");
			storeReports("upGradAssignment_sortByNoOfRatings");

			System.out.println("Task Complete");

		} catch (Exception e) {
			System.out.print("Script Failed");
			driver.quit();
		}
		driver.quit();

	}
}
